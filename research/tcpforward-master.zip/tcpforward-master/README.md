# tcpforward
simplest tcp forwarder in go

Usage:

    ./tcpforward -l localhost:port -r remotehost:port -p <logprefix>
